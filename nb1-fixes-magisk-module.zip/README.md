# Introduction

This module applies some fixes for Nokia 8:
- audio volume curves for making volume tracker more consistent with output
- adds a handful of missing SELinux policies

## What you need

* Magisk v21.1+
* Custom ROM for Nokia 8
