chown system:system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/min_freq
chown system:system /sys/devices/soc/soc:qcom,cpubw/devfreq/soc:qcom,cpubw/max_freq
chown system:system /sys/class/kgsl/kgsl-3d0/devfreq/min_freq
chown system:system /sys/class/kgsl/kgsl-3d0/devfreq/max_freq
chown system:system /sys/class/devfreq/soc:qcom,gpubw/min_freq
chown system:system /sys/class/devfreq/soc:qcom,gpubw/max_freq
chown system:system /dev/stune/top-app/schedtune.boost
