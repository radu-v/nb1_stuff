# Introduction

This module applies some fixes for Nokia 8:
- adds a handful of missing SELinux policies
- patched libraries to fix hw keys and camera
- framework-res overlay

## What you need

* Magisk v22+
* Custom ROM or GSI for Nokia 8
